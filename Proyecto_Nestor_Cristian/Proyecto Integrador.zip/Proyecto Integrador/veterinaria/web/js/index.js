function cargarLoginEmpleado()
{
        window.location = "gestiones/login/loginEmpleado.html";
}

function cargarLoginCliente()
{
        window.location = "gestiones/login/loginCliente.html";
}

