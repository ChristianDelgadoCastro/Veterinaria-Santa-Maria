function cargarLoginEmpleado()
{
        window.location = "../../gestiones/login/loginEmpleado.html";
}

